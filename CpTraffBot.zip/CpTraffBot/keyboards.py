from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton

b1 = KeyboardButton('💋Приватный канал')
b2 = KeyboardButton('📝Ознакомительный архив')
b3 = KeyboardButton('💾Реферальная программа')
b4 = KeyboardButton('🛠Техническая поддержка')
start_keyboard = ReplyKeyboardMarkup(resize_keyboard=True).add(b1, b2).add(b3, b4)

b5 = InlineKeyboardButton('📧 Рассылка', callback_data='mail')
b6 = InlineKeyboardButton('🗄 Выгрузка БД', callback_data='dump')
admin_keyboard = InlineKeyboardMarkup(resize_keyboard=True).add(b5).add(b6)