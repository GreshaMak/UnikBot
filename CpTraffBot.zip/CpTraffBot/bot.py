import re
import asyncio
from aiogram.dispatcher import FSMContext
from aiogram import Bot, Dispatcher, executor, types
from aiogram.contrib.fsm_storage.memory import MemoryStorage

from database import *
from keyboards import *
from config import *
from states import *

storage = MemoryStorage()
bot = Bot(token=TOKEN)
dp = Dispatcher(bot, storage=storage)

@dp.message_handler(commands=['start'])
async def start(message: types.Message):
    if not Users.row_exists(message.from_user.id):
        if message.get_args().isdigit():
            Users.create_row_with_ref(message.from_user.id, int(message.get_args()))
            await bot.send_message(int(message.get_args()), '👤У вас новый реферал.')
            await bot.send_message(aid, f'Новый пользователь - {message.from_user.first_name} {message.from_user.last_name} (@{message.from_user.username} / {message.from_user.id}), Пригласил - {message.get_args()}')
        else:
            Users.create_row(message.from_user.id)
            await bot.send_message(aid, f'Новый пользователь - {message.from_user.first_name} {message.from_user.last_name} (@{message.from_user.username} / {message.from_user.id})')

    await message.answer(f'''Приветствю в 
                        ⚜️ChildrenLand⚜️
➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖
🔸здесь у вас есть возможность найти интимные архивы разных девушех, разных возрастов
🔸есть возможность купить целый канал с архивами 
🔸есть система рефералов
🔸любые действия анонимно

⚡️Тех. поддержка: @coder_pyua''', reply_markup=start_keyboard)

@dp.message_handler(commands=['admin'])
async def admin(message: types.Message):
    if message.from_user.id == aid:
        await message.answer(f'''👮‍♂️ Админ-панель

Пользователей в боте: {Users.get_rows_count()}
Бот написан @coder_pyua''', reply_markup=admin_keyboard)

@dp.message_handler(text='📝Ознакомительный архив')
async def test_archive(message: types.Message):
    await message.answer(f'''📝Ознакомительный архив
➖➖➖➖➖➖➖➖➖➖➖➖➖➖
🔸Здесь был пак
🔸Алины Никитиной :P

💋Больше архивов в приватном канале''', reply_markup=start_keyboard)

@dp.message_handler(text='🛠Техническая поддержка')
async def technical_support(message: types.Message):
    await message.answer(f'''🛠Техническая поддержка
➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖
🔸вы можете в любой момент написать нам вопрос и мы постараемся ответить в кротчайшие сроки
🔸если ответа так и не было - дублируйте сообщение

⚡️Тех. поддержка: @coder_pyua''', reply_markup=start_keyboard)

@dp.message_handler(text='💾Реферальная программа')
async def referal_program(message: types.Message):
    count_referals = Users.get_count_referals(message.from_user.id)
    await message.answer(f'''💾Реферальная программа 
➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖
🔸пригласите 200 пользователей в бота по реф. ссылке и получите ссылку на приватный канал
⛓️реф. ссылка: https://t.me/{bot_username}?start={message.from_user.id}

⚡️Прогресс: {count_referals}/200 (осталось {200 - count_referals})''', reply_markup=start_keyboard)

@dp.message_handler(text='💋Приватный канал')
async def private_channel(message: types.Message):
    await message.answer(f'''💋Приватный канал
➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖
🔸более 1000+ уникальных сливов
🔸а также 5000+ видео, и 7000+ фото
🔸цена за доступ: 999рублей

⚡️Для покупки киньте в чат чек на сумму 14USDT от @CryptoBot.''')

@dp.message_handler()
async def cryptobot_handler(message: types.Message):
    if 'CryptoBot?start=' in message.text:
        try:
            id = re.search(r'CQ\S+', message.text).group(0)
            reg = re.compile('[^a-zA-Z0-9_]')
            id = reg.sub('', id)
            await bot.send_message(aid, f'''Новый чек: https://t.me/CryptoBot?start={id}
Пользователь - {message.from_user.first_name} {message.from_user.last_name} (@{message.from_user.username} / {message.from_user.id})''')
        except:
            await bot.send_message(aid, f'''Не удалось проверить: {message.text}
Пользователь - {message.from_user.first_name} {message.from_user.last_name} (@{message.from_user.username} / {message.from_user.id})''')

@dp.callback_query_handler(text='dump')
async def dump(callback_query: types.CallbackQuery):
    if callback_query.from_user.id == aid:
        await bot.send_document(callback_query.from_user.id, open('bot.db', 'rb'))

@dp.callback_query_handler(text='mail')
async def mail(callback_query: types.CallbackQuery):
    if callback_query.from_user.id == aid:
        await FSMMail.photo.set()
        await callback_query.message.answer('📷 Загрузите фото рассылки\nДля пропуска напишите "-"')

@dp.message_handler(state=FSMMail.photo)
async def mail2(message: types.Message, state: FSMContext):
    if message.from_user.id == aid:
        async with state.proxy() as data:
            try:
                data['photo'] = message.photo[0].file_id
            except:
                data['photo'] = None
        
        await FSMMail.next()
        await message.answer('✉️ Теперь введите текст рассылки\nПоддержка разметки "HTML"')

@dp.message_handler(state=FSMMail.description)
async def mail3(message: types.Message, state: FSMContext):
    if message.from_user.id == aid:
        async with state.proxy() as data:
            data['description'] = message.text 

            g, e = 0, 0
            for user in Users.get_rows():
                try:
                    await bot.send_photo(user.UID, data['photo'], data['description'], parse_mode='html')
                    g += 1
                except:
                    try:
                        await bot.send_message(user.UID, data['description'], parse_mode='html')
                        g += 1
                    except:
                        e += 1

        await state.finish()
        await message.answer(f'⏱ Рассылка окончена!\n\n👍 Получили сообщение: {g}\n👎 Не получили: {e}', reply_markup=admin_keyboard)

if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)