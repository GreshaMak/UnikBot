TOKEN = "7405979047:AAFONx57YRxHkDIY9eaJRhkHhLHJOn6Bhg4"
bot_username = "qumati_bot"
aid = 7016182279