from peewee import *

db = SqliteDatabase('bot.db')

class BaseModel(Model):
    class Meta:
        database = db

class Users(BaseModel):
    UID = BigIntegerField(unique=True)
    REF = BigIntegerField(default=0)

    @classmethod
    def get_rows_count(cls):
        return len(cls.select())

    @classmethod
    def get_rows(cls):
        return cls.select()

    @classmethod
    def get_row(cls, UID):
        return cls.get(UID == UID)

    @classmethod
    def row_exists(cls, UID):
        query = cls().select().where(cls.UID == UID)
        return query.exists()

    @classmethod
    def create_row(cls, UID):
        user, created = cls.get_or_create(UID=UID, REF=0)

    @classmethod
    def create_row_with_ref(cls, UID, REF):
        user, created = cls.get_or_create(UID=UID, REF=REF)

    @classmethod
    def get_count_referals(cls, UID):
        return len(cls.select().where(cls.REF == UID))

db.create_tables([Users])