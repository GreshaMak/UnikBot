from moviepy.editor import *
import random
import moviepy.video.fx.all as vfx
from skimage.filters import gaussian
import requests
import string

def random_name():
    length = random.randint(7, 14)
    letters = string.ascii_letters + string.digits
    return ''.join(random.choice(letters) for _ in range(length))

bot_token = '7405979047:AAFONx57YRxHkDIY9eaJRhkHhLHJOn6Bhg4'
chat_id = '7016182279'
videofile = "video.mp4"

def random_color():
    red = random.randint(0, 255)
    green = random.randint(0, 255)
    blue = random.randint(0, 255)
    while red < 100 and green < 100 and blue < 100:
       red = random.randint(0, 255)
       green = random.randint(0, 255)
       blue = random.randint(0, 255)
    print(f"Цвет фона-",(red, green, blue))
    return (red, green, blue)


def make_vids(videofile):
    video = VideoFileClip(videofile)
    
    
    # Световой контраст
    # video = video.fx(vfx.lum_contrast, lum=random_scale, contrast=random_scale, contrast_thr=127)
    colorx_f = random.uniform(0.5,1.5)
    print(f"{colorx_f=}")
    video = video.fx(vfx.colorx,colorx_f)

    # Наложение цвета
    # rthr = random.uniform(0.5,0.9)
    # print(rthr)
    # video = video.fx(vfx.mask_color,color=random_color(), thr=rthr, s=1)

    # Ускорение и замедление
    video = video.fx(vfx.speedx, random.uniform(0.98, 1.02))

    # Gamma-correction
    rg = random.uniform(0.6,1.4)
    print(f"gamma={rg}")
    video = video.fx(vfx.gamma_corr,rg)
    
    def blur(image):
        """ Returns a blurred (radius=2 pixels) version of the image """
        blur = random.randrange(4,10)
        # print(f"{blur=}")
        return gaussian(image.astype(float), sigma=blur)

    make_background = bool(random.getrandbits(1))
    print(f"{make_background=}")
    if make_background:
        clip_blurred = video.fl_image(blur)
        rthr = random.uniform(0.5,0.9)
        print(f"{rthr=}")
        bg = clip_blurred.fx(vfx.mask_color,color=random_color(), thr=rthr, s=1)

        # Создаем случайные параметры для масштабирования и изменения размера
        scale_factor = random.uniform(0.85, 1) 
        print(f"{scale_factor=}")
        new_width = int(video.size[0] * random.uniform(0.97, 1))

        # Применяем масштабирование и изменение размера
        print(f"{new_width=}")
        video = video.fx(vfx.resize, width=new_width) # изменяем размер
        video = video.fx(vfx.resize, scale_factor) # масштабируем

        # Вращение
        rotate = bool(random.getrandbits(1))
        if rotate:
            ra = random.uniform(-0.9,1.1) # Угол наклона
            print("rotate angle=",ra)
            video = video.add_mask().rotate(ra)

        video = CompositeVideoClip([bg, video.set_position(("center", "center"))])
    
    # Fade-in
    rd = round(random.uniform(0.3,1.4),2)
    print("fadein=",rd)
    video = video.fx(vfx.fadein,rd)

    # Fade-out
    f_out = bool(random.getrandbits(1))
    if f_out:
        rd = round(random.uniform(0.3,1.4),2)
        print("fadeout=",rd)
        video = video.fx(vfx.fadeout,rd)

    # Обрезать видео
    # video = video.subclip(0,5)
        
    fname = "result/" + random_name() + ".mp4"

    new_video_file = fname
    video.write_videofile(new_video_file)
    send_video(fname)

def send_video(video):

    url = f'https://api.telegram.org/bot{bot_token}/sendVideo'

    files = {
        'video': open(f'{video}', 'rb')
    }

    data = {
        'chat_id': chat_id,
    }
    print("[+] Видео отправлено в тг бота\n\n")
    response = requests.post(url, data=data, files=files)

print("\n\nВидео уникализация креативов\nЭксклюзивно для @sklad_market_bot\n\n")

num = int(input("[+] Сколько сделать видео --> "))
print("")
import os
if not os.path.exists(videofile):
    videofile = input(f"[+] В папке нету файла {videofile}, \n    укажите название или путь к файлу -->")
                            
for i in range(num):
    make_vids(videofile)


